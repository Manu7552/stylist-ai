# DressMe AI
Next.js 14 · TypeScript · Tailwind. Real try-on via Replicate (IDM-VTON/CatVTON), styling via Anthropic vision.

## Setup
1. `npm install`
2. `cp .env.example .env.local`, fill keys. Replicate: open the try-on model page (e.g. cuuupid/idm-vton), copy its latest version hash into `REPLICATE_TRYON_VERSION`.
3. `npm run dev` → http://localhost:3000
4. Deploy: push to GitHub, import in Vercel, add the same env vars. Try-on can take ~90s, so use a plan allowing `maxDuration` 180 (or move to a background job).

## Working vs demo
- Working: uploads, validation, previews, before/after slider, real try-on, JSON styling analysis, profile-only styling (no garment), comparison scores, wardrobe (favourites, collections, delete), download.
- Demo mode: if a key is missing, `/api/status` reports it, the UI says so, and generation buttons are disabled. No fake results are ever shown.
- Not yet wired: Supabase auth/storage. `supabase/schema.sql` has the tables, RLS and storage notes; wardrobe currently lives in localStorage. Provider result URLs expire, so persist to Supabase Storage next.

## Privacy
Images go server-side to the providers only for the request, are not stored by this app, and keys stay on the server.
