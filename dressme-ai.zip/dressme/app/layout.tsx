import "./globals.css";
import { Instrument_Serif, Manrope } from "next/font/google";
const serif = Instrument_Serif({ subsets: ["latin"], weight: "400", variable: "--serif" });
const sans = Manrope({ subsets: ["latin"], variable: "--sans" });
export const metadata = { title: "DressMe AI", description: "See yourself in every style." };
export default function L({ children }: { children: React.ReactNode }) {
  return <html lang="en" className={`${serif.variable} ${sans.variable}`}><body>{children}</body></html>;
}
