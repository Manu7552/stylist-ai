import { hasTryOn, hasAnalysis } from "@/lib/ai";
export const GET = () => Response.json({ tryOn: hasTryOn(), analysis: hasAnalysis() });
