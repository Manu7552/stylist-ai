import { hasTryOn, runTryOn, toDataUri } from "@/lib/ai";
export const maxDuration = 180;
export async function POST(req: Request) {
  try {
    if (!hasTryOn()) return Response.json({ error: "Demo mode: no try-on provider configured." }, { status: 503 });
    const f = await req.formData();
    const person = f.get("person"), garment = f.get("garment");
    if (!(person instanceof File) || !(garment instanceof File)) return Response.json({ error: "Both images are required." }, { status: 400 });
    const url = await runTryOn(await toDataUri(person), await toDataUri(garment), String(f.get("category") || "upper_body"), String(f.get("desc") || ""));
    return Response.json({ url });
  } catch (e: any) { return Response.json({ error: e.message || "Unexpected error." }, { status: 500 }); }
}
