import { analyze, hasAnalysis, toDataUri } from "@/lib/ai";
export const maxDuration = 60;
export async function POST(req: Request) {
  try {
    if (!hasAnalysis()) return Response.json({ error: "Demo mode: no analysis provider configured." }, { status: 503 });
    const f = await req.formData();
    const person = f.get("person"); const result = f.get("result"); const mode = result ? "outfit" : "profile";
    if (!(person instanceof File)) return Response.json({ error: "Your photo is required." }, { status: 400 });
    const imgs = [await toDataUri(person)];
    if (result instanceof File) imgs.push(await toDataUri(result));
    else if (typeof result === "string" && result) {
      const b = await fetch(result); imgs.push(`data:${b.headers.get("content-type") || "image/png"};base64,${Buffer.from(await b.arrayBuffer()).toString("base64")}`);
    }
    return Response.json(await analyze(imgs, mode));
  } catch (e: any) { return Response.json({ error: e.message || "Unexpected error." }, { status: 500 }); }
}
