"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type A = any;
type Look = { id: string; result: string; person: string; analysis?: A; fav: boolean; collection: string; at: number };
const OK = ["image/jpeg", "image/png", "image/webp"], MAX = 8 * 1024 * 1024;
const preview = (f: File) => URL.createObjectURL(f);

function Drop({ label, hint, file, onFile }: { label: string; hint: string; file: File | null; onFile: (f: File | null) => void }) {
  const [err, setErr] = useState("");
  const pick = (f?: File) => {
    if (!f) return;
    if (!OK.includes(f.type)) return setErr("Use JPG, PNG or WEBP.");
    if (f.size > MAX) return setErr("Max size is 8 MB.");
    setErr(""); onFile(f);
  };
  return (<div>
    <p className="mb-2 font-medium">{label}</p>
    <label className="relative flex aspect-[3/4] cursor-pointer items-center justify-center overflow-hidden rounded-3xl border border-dashed border-stone-deep bg-stone/40 text-center text-sm text-stone-deep">
      {file ? <img src={preview(file)} alt={label} className="h-full w-full object-cover" /> : <span className="px-6">{hint}<br />JPG, PNG or WEBP, up to 8 MB</span>}
      <input type="file" accept={OK.join(",")} className="sr-only" onChange={e => pick(e.target.files?.[0])} />
    </label>
    <div className="mt-2 flex gap-4 text-sm">
      {file && <button onClick={() => onFile(null)} className="underline">Remove</button>}
      {err && <span role="alert" className="text-red-700">{err}</span>}
    </div>
  </div>);
}

function Compare({ before, after }: { before: string; after: string }) {
  const [v, setV] = useState(50);
  return (<div className="relative mx-auto aspect-[3/4] max-w-md overflow-hidden rounded-3xl">
    <img src={after} alt="Your look" className="absolute inset-0 h-full w-full object-cover" />
    <img src={before} alt="Original" className="absolute inset-0 h-full w-full object-cover" style={{ clipPath: `inset(0 ${100 - v}% 0 0)` }} />
    <input aria-label="Before and after" type="range" value={v} onChange={e => setV(+e.target.value)} className="absolute bottom-4 left-4 right-4 accent-black" />
  </div>);
}

const List = ({ t, items }: { t: string; items?: string[] }) => items?.length ? <div><h4 className="font-serif text-xl">{t}</h4><ul className="mt-1 list-disc pl-5 text-sm">{items.map((x, i) => <li key={i}>{x}</li>)}</ul></div> : null;

function Advice({ a }: { a: A }) {
  return (<div className="space-y-5 rounded-3xl bg-stone p-6 md:p-8">
    {a.profile && <p className="text-sm"><b>Read from your photo (estimate):</b> {Object.values(a.profile).filter(Boolean).join(" · ")}</p>}
    {a.verdict && <p className="font-serif text-2xl">{a.verdict}</p>}
    {["color", "fit", "coordination"].map(k => a[k] && <p key={k} className="text-sm"><b className="capitalize">{k}:</b> {a[k]}</p>)}
    <div className="grid gap-5 md:grid-cols-2">
      <List t="Trousers" items={a.trousers} /><List t="Shoes" items={a.shoes} /><List t="Watch & accessories" items={a.accessories} />
      <List t="Occasions" items={a.occasions} /><List t="Improve this look" items={a.improvements} />
      <List t="Styles that suit you" items={a.recommendedStyles} /><List t="Best colours" items={a.bestColors} /><List t="Avoid" items={a.avoid} />
    </div>
  </div>);
}

export default function Studio() {
  const [tab, setTab] = useState<"studio" | "compare" | "wardrobe">("studio");
  const [status, setStatus] = useState<{ tryOn: boolean; analysis: boolean } | null>(null);
  const [person, setPerson] = useState<File | null>(null), [garment, setGarment] = useState<File | null>(null);
  const [category, setCategory] = useState("upper_body"), [desc, setDesc] = useState("");
  const [busy, setBusy] = useState(""), [err, setErr] = useState("");
  const [result, setResult] = useState(""), [analysis, setAnalysis] = useState<A>(null);
  const [looks, setLooks] = useState<Look[]>([]), [sel, setSel] = useState<string[]>([]);

  useEffect(() => {
    fetch("/api/status").then(r => r.json()).then(setStatus).catch(() => setStatus({ tryOn: false, analysis: false }));
    try { setLooks(JSON.parse(localStorage.getItem("dressme-looks") || "[]")); } catch {}
  }, []);
  const persist = (l: Look[]) => { setLooks(l); try { localStorage.setItem("dressme-looks", JSON.stringify(l)); } catch { setErr("Browser storage is full. Delete some looks."); } };

  const post = async (url: string, fd: FormData) => {
    const r = await fetch(url, { method: "POST", body: fd }); const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Something went wrong. Try again."); return j;
  };
  const analyse = async (resultUrl?: string) => {
    const fd = new FormData(); fd.append("person", person!); if (resultUrl) fd.append("result", resultUrl);
    return post("/api/analyze", fd);
  };
  const generate = async () => {
    setErr(""); setResult(""); setAnalysis(null);
    try {
      setBusy("Dressing you in the garment. This usually takes 30 to 90 seconds.");
      const fd = new FormData(); fd.append("person", person!); fd.append("garment", garment!); fd.append("category", category); fd.append("desc", desc);
      const { url } = await post("/api/tryon", fd); setResult(url);
      if (status?.analysis) { setBusy("Your stylist is reviewing the look."); setAnalysis(await analyse(url)); }
    } catch (e: any) { setErr(e.message); } finally { setBusy(""); }
  };
  const styleMe = async () => {
    setErr(""); setResult(""); setAnalysis(null); setBusy("Reading your proportions and colouring.");
    try { setAnalysis(await analyse()); } catch (e: any) { setErr(e.message); } finally { setBusy(""); }
  };
  const save = () => {
    const rd = new FileReader();
    rd.onload = () => persist([{ id: crypto.randomUUID(), result, person: String(rd.result), analysis, fav: false, collection: "Unsorted", at: Date.now() }, ...looks]);
    rd.readAsDataURL(person!); // small thumbnail storage; result URLs from providers may expire, so download looks you love
  };
  const best = looks.filter(l => sel.includes(l.id) && l.analysis?.scores).sort((a, b) => avg(b) - avg(a))[0];
  const avg = (l: Look) => ((l.analysis?.scores?.style || 0) + (l.analysis?.scores?.color || 0) + (l.analysis?.scores?.fit || 0)) / 3;
  const cols = [...new Set(looks.map(l => l.collection))];

  return (<main className="mx-auto max-w-6xl px-6 py-6">
    <header className="flex items-center justify-between"><Link href="/" className="font-serif text-2xl">DressMe AI</Link>
      <nav className="flex gap-1 rounded-full bg-stone p-1 text-sm">
        {(["studio", "compare", "wardrobe"] as const).map(t => <button key={t} onClick={() => setTab(t)} className={`rounded-full px-4 py-2 capitalize ${tab === t ? "bg-black text-white" : ""}`}>{t === "compare" ? "Compare" : t === "wardrobe" ? "My wardrobe" : "Studio"}</button>)}
      </nav></header>

    {status && (!status.tryOn || !status.analysis) && <p className="mt-6 rounded-2xl border border-black p-4 text-sm" role="status">
      <b>Demo mode.</b> {!status.tryOn && "Virtual try-on is off (set REPLICATE_* keys). "}{!status.analysis && "Style analysis is off (set ANTHROPIC_API_KEY). "}Uploads and previews work, but no results are generated until keys are added.</p>}

    {tab === "studio" && <section className="mt-10">
      <h1 className="font-serif text-5xl">Studio</h1>
      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <div><Drop label="Your photo" hint="Full-body, facing the camera, even light, plain background." file={person} onFile={setPerson} /></div>
        <div><Drop label="Clothing (optional)" hint="A shirt, trousers, jacket or dress on a clean background." file={garment} onFile={setGarment} />
          <div className="mt-4 grid gap-3 text-sm">
            <select value={category} onChange={e => setCategory(e.target.value)} className="rounded-xl border p-3" aria-label="Garment type">
              <option value="upper_body">Shirt, T-shirt or jacket</option><option value="lower_body">Trousers or jeans</option><option value="dresses">Dress or full outfit</option></select>
            <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Describe it, e.g. navy slim-fit shirt" className="rounded-xl border p-3" /></div></div>
      </div>
      <div className="mt-8 flex flex-wrap gap-3">
        <button disabled={!person || !garment || !!busy || status?.tryOn === false} onClick={generate} className="rounded-full bg-black px-8 py-4 text-white disabled:opacity-30">Generate My Look</button>
        <button disabled={!person || !!busy || status?.analysis === false} onClick={styleMe} className="rounded-full border border-black px-8 py-4 disabled:opacity-30">No outfit? Style me from my photo</button>
      </div>
      {busy && <div className="relative mt-8 overflow-hidden rounded-3xl bg-stone p-10" role="status"><div className="sweep absolute inset-x-0 h-1/2 bg-gradient-to-b from-transparent via-white/70 to-transparent" /><p className="relative">{busy}</p></div>}
      {err && <p role="alert" className="mt-6 rounded-2xl bg-red-50 p-4 text-red-800">{err}</p>}
      {result && person && <div className="mt-10"><Compare before={preview(person)} after={result} />
        <div className="mt-4 flex justify-center gap-3 text-sm">
          <a href={result} download="dressme-look.png" target="_blank" rel="noreferrer" className="rounded-full border border-black px-5 py-2">Download</a>
          <button onClick={save} className="rounded-full bg-black px-5 py-2 text-white">Save look</button>
          <button onClick={() => { setResult(""); setAnalysis(null); }} className="rounded-full border px-5 py-2">Delete result</button></div></div>}
      {analysis && <div className="mt-10"><Advice a={analysis} /></div>}
    </section>}

    {tab === "compare" && <section className="mt-10"><h1 className="font-serif text-5xl">Compare</h1>
      <p className="mt-2 text-stone-deep">Select 2 or more saved looks that were analysed.</p>
      {looks.length < 2 ? <p className="mt-8">Save at least two looks in the studio first.</p> : <>
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">{looks.map(l => <button key={l.id} onClick={() => setSel(s => s.includes(l.id) ? s.filter(x => x !== l.id) : [...s, l.id])}
          className={`overflow-hidden rounded-3xl text-left ring-2 ${sel.includes(l.id) ? "ring-black" : "ring-transparent"}`}>
          <img src={l.result} alt="Saved look" className="aspect-[3/4] w-full object-cover" />
          <div className="p-3 text-xs">{l.analysis?.scores ? `Style ${l.analysis.scores.style} · Colour ${l.analysis.scores.color} · Fit ${l.analysis.scores.fit}` : "Not analysed"}</div></button>)}</div>
        {sel.length > 1 && best && <p className="mt-8 rounded-3xl bg-stone p-6 font-serif text-2xl">Best look: the one scoring {Math.round(avg(best))} overall. {best.analysis.verdict}</p>}</>}
    </section>}

    {tab === "wardrobe" && <section className="mt-10"><div className="flex items-end justify-between"><h1 className="font-serif text-5xl">My wardrobe</h1>
      {looks.length > 0 && <button className="text-sm underline" onClick={() => confirm("Delete all saved looks?") && persist([])}>Delete everything</button>}</div>
      {looks.length === 0 ? <p className="mt-8">Nothing saved yet. Generate a look in the studio and choose Save look.</p> :
        cols.map(c => <div key={c} className="mt-8"><h2 className="font-serif text-2xl">{c}</h2>
          <div className="mt-3 grid grid-cols-2 gap-4 md:grid-cols-4">{looks.filter(l => l.collection === c).map(l => <figure key={l.id}>
            <img src={l.result} alt="Saved look" className="aspect-[3/4] w-full rounded-3xl object-cover" />
            <figcaption className="mt-2 flex flex-wrap gap-3 text-xs">
              <button onClick={() => persist(looks.map(x => x.id === l.id ? { ...x, fav: !x.fav } : x))}>{l.fav ? "★ Favourite" : "☆ Favourite"}</button>
              <button onClick={() => { const n = prompt("Collection name", l.collection); if (n) persist(looks.map(x => x.id === l.id ? { ...x, collection: n } : x)); }}>Move</button>
              <button onClick={() => persist(looks.filter(x => x.id !== l.id))}>Delete</button></figcaption></figure>)}</div></div>)}
    </section>}
  </main>);
}
