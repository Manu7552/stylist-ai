import Link from "next/link";
const steps = ["Upload a photo of yourself", "Upload a garment", "Generate your look and get styling notes"];
export default function Home() {
  return (<main>
    <header className="flex items-center justify-between px-6 py-5 md:px-12">
      <span className="font-serif text-2xl">DressMe AI</span>
      <Link href="/studio" className="text-sm underline underline-offset-4">Open studio</Link>
    </header>
    <section className="px-6 pb-24 pt-16 md:px-12 md:pt-28">
      <h1 className="max-w-4xl font-serif text-6xl leading-[0.95] md:text-9xl">See Yourself in Every Style.</h1>
      <p className="mt-8 max-w-xl text-lg text-stone-deep">Upload a photo and any garment. A real virtual try-on model dresses you in it, then a vision model tells you what works on your build, colouring and proportions.</p>
      <Link href="/studio" className="mt-10 inline-block rounded-full bg-black px-8 py-4 text-white transition hover:bg-stone-deep">Try Your First Outfit</Link>
    </section>
    <section className="bg-stone px-6 py-20 md:px-12">
      <h2 className="font-serif text-4xl">How it works</h2>
      <ol className="mt-8 grid gap-4 md:grid-cols-3">{steps.map((s, i) => <li key={i} className="rounded-3xl bg-white p-8 text-lg">{i + 1}. {s}</li>)}</ol>
      <p className="mt-8 max-w-2xl text-stone-deep">No second photo? Skip the garment and get style, colour and fit recommendations from your photo alone. Results shown in the studio are always generated live. This site never displays placeholder images as AI output.</p>
    </section>
    <section className="px-6 py-20 md:px-12">
      <h2 className="font-serif text-4xl">Your images, handled carefully</h2>
      <p className="mt-4 max-w-2xl text-stone-deep">Photos are sent to the try-on and analysis providers only to produce your result, over your own server. API keys never reach the browser. Your wardrobe is stored in your own browser and you can delete any look or wipe everything in one click.</p>
    </section>
  </main>);
}
