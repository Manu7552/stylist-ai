create table collections (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users not null, name text not null, created_at timestamptz default now());
create table outfits (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users not null,
  collection_id uuid references collections on delete set null, person_path text, garment_path text, result_path text,
  analysis jsonb, favourite boolean default false, created_at timestamptz default now());
alter table collections enable row level security; alter table outfits enable row level security;
create policy "own collections" on collections for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own outfits" on outfits for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
-- Storage: private bucket "looks", policy limiting objects to folder = auth.uid().
