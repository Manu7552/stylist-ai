module.exports={content:["./app/**/*.tsx"],theme:{extend:{fontFamily:{serif:["var(--serif)"],sans:["var(--sans)"]},colors:{stone:{DEFAULT:"#e9e7e2",deep:"#8a867e"}}}}}
