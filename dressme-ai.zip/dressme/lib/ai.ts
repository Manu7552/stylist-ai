// Server-only AI adapters. Swap providers by editing this file only.
export const hasTryOn = () => !!(process.env.REPLICATE_API_TOKEN && process.env.REPLICATE_TRYON_VERSION);
export const hasAnalysis = () => !!process.env.ANTHROPIC_API_KEY;
export const MAX_BYTES = 8 * 1024 * 1024;
export const TYPES = ["image/jpeg", "image/png", "image/webp"];

export async function toDataUri(f: File) {
  if (!TYPES.includes(f.type)) throw new Error("Use JPG, PNG or WEBP images.");
  if (f.size > MAX_BYTES) throw new Error("Images must be under 8 MB.");
  return `data:${f.type};base64,${Buffer.from(await f.arrayBuffer()).toString("base64")}`;
}

export async function runTryOn(person: string, garment: string, category: string, desc: string) {
  const h = { Authorization: `Bearer ${process.env.REPLICATE_API_TOKEN}`, "Content-Type": "application/json" };
  const start = await fetch("https://api.replicate.com/v1/predictions", {
    method: "POST", headers: h,
    body: JSON.stringify({ version: process.env.REPLICATE_TRYON_VERSION, input: {
      human_img: person, garm_img: garment, garment_des: desc || "clothing item", category, crop: false, steps: 30 } }),
  });
  if (!start.ok) throw new Error(`Try-on provider rejected the request (${start.status}).`);
  let p = await start.json();
  const t0 = Date.now();
  while (!["succeeded", "failed", "canceled"].includes(p.status)) {
    if (Date.now() - t0 > 150_000) throw new Error("Try-on timed out. Please try again.");
    await new Promise(r => setTimeout(r, 2500));
    p = await (await fetch(p.urls.get, { headers: h })).json();
  }
  if (p.status !== "succeeded") throw new Error(p.error || "Generation failed. Try clearer photos.");
  return Array.isArray(p.output) ? p.output[0] : p.output as string;
}

const SCHEMA = `{"profile":{"bodyShape":"","faceShape":"","skinTone":"","build":"","sizeEstimate":""},
"scores":{"style":0-100,"color":0-100,"fit":0-100},
"color":"","fit":"","coordination":"","trousers":[""],"shoes":[""],"accessories":[""],
"occasions":[""],"improvements":[""],"recommendedStyles":[""],"bestColors":[""],"avoid":[""],"verdict":""}`;

export async function analyze(images: string[], mode: "outfit" | "profile") {
  const task = mode === "outfit"
    ? "Image 1 is the person, image 2 is the generated try-on result. Critique the outfit shown in image 2."
    : "Image 1 is the person only. Recommend clothing styles for them; leave scores at 0 and outfit-specific fields empty.";
  const content: any[] = images.map(d => ({ type: "image", source: { type: "base64",
    media_type: d.slice(5, d.indexOf(";")), data: d.split(",")[1] } }));
  content.push({ type: "text", text: `${task} Base advice on visible body shape, proportions, face shape, skin tone and estimated size range (say "estimate"). Be specific and actionable, no generic compliments. Reply with ONLY JSON matching: ${SCHEMA}` });
  const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST",
    headers: { "x-api-key": process.env.ANTHROPIC_API_KEY!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 1500, messages: [{ role: "user", content }] }) });
  if (!r.ok) throw new Error(`Analysis provider error (${r.status}).`);
  const txt = (await r.json()).content?.find((c: any) => c.type === "text")?.text ?? "";
  return JSON.parse(txt.replace(/```json|```/g, "").trim());
}
